import unittest
from unittest import mock
from pyURControl import ur_control

class TestURControl(unittest.TestCase):
    def __init__(self, methodName: str = "runTest") -> None:
        super().__init__(methodName)

    def setUp(self) -> None:
        pass

    def test_power_on(self):
        # arrange
        #!TDB

        # act

        # assert
        self.assertEqual(True, True)