def get_powering_on():
    pass